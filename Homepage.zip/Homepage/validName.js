function myFunction() {
var name = document.getElementByName("name").value;
var email = document.getElementByName("email").value;
var msg = document.getElementByName("msg").value;
var country = document.getElementByName("country").value;

var dataString = 'name=' + name + '&email=' + email + '&msg=' + msg + '&country=' + country;
if (name == '' || email == '' || msg == '' || country == '') {
alert("Please Fill All Fields");
}
else {
$.ajax({
type: "POST",
url: "insert.php",
data: dataString,
cache: false,
success: function(response) {
	if(response=="TRUE"){
 $('#msg').html("Username Already Exists");
}
else{
	 $('#msg').html("");
}
});
}
return false;
}