<?php

namespace Drupal\customer\Controller;

use Drupal\Core\Controller\ControllerBase;

/**
 * An example controller
 */
class Controller extends ControllerBase {

    /**
     * Returns String Message
     */
    public function display() {
        $msg = [
            '#markup' => $this->t('If U r a New User gothrough Registration else go with SignUp'),
        ];
        return $msg;
    }

}